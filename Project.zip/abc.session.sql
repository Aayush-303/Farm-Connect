-- CREATE TABLE `admin` (
--   `admin_id` int(20) NOT NULL,
--   `admin_name` varchar(100) NOT NULL,
--   `admin_password` varchar(100) NOT NULL
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --
-- -- Dumping data for table `admin`
-- --

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`) VALUES
(1, 'admin', 'password');